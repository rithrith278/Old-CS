#include "BSTree.h"

#include <iostream>
#include <queue>

using namespace std;

////////////////////////////////////////////////////
// A few functions are already implemented for you
// and you can use them (but do not change them).
//
// SCROLL BELOW TO SEE THE FUNCTIONS THAT YOU HAVE
// TO IMPLEMENT.
/////////////////////////////////////////////////////


// input / output operators
ostream& operator<<(ostream& out, BSTree& tree)
{
    tree.print_level_by_level(out);
    return out;
}

ostream& operator<<(ostream& out, Node& node)
{
    return out << node.value << "[" << node.search_time << "]";
}

istream& operator>>(istream& in, BSTree& tree)
{
    /*
      Take input from the input stream, and build your tree.
      Input should look like this (one int in a line):
      4 
      2 
      6 
      1 
      3 
      5 
      7
    */
    int next;
    while(in >> next) {
        tree.insert(next);
    }
    return in;
}

// Example recursive function
// If you try to use it without care, you will get a memory leak.
void BSTree::copy_helper(Node*& newNode, const Node* sourceNode) {
    //Don't copy if the node is nullptr
    if(sourceNode == nullptr)
        return;

    //Change the new node to a copy of sourceNode
    newNode = new Node(sourceNode->value);
    //Copy over the search cost
    newNode->search_time = sourceNode->search_time;

    //Copy left subtree
    if (sourceNode->left != nullptr)
        copy_helper(newNode->left, sourceNode->left);
    //Copy right subtree
    if(sourceNode->right != nullptr)
        copy_helper(newNode->right, sourceNode->right);
}

void BSTree::delete_helper(Node *&node)
{
  if(node != nullptr)
  {
    delete_helper(node->left);
    delete_helper(node->right);
    delete node;
  }
  node = nullptr;
}

Node *BSTree::insert_helper(Node *&node, int val, int cost)
{
    if(node == nullptr){node = new Node(val);node->search_time=cost;}
    else if(val < node->value){insert_helper(node->left, val, cost+1);}
    else if(val > node->value){insert_helper(node->right, val, cost+1);}
    return node;
}

Node *BSTree::search_helper(Node *node, int val)
{
  if(node == nullptr){return nullptr;}
  else if(val < node->value){return search_helper(node->left, val);}
  else if(val > node->value){return search_helper(node->right, val);}
  else{return node;}
}

void BSTree::inorder_helper(Node *node, std::ostream &out)
{
  if(node == nullptr){return;}

  inorder_helper(node->left, out);

  out << *node << " ";

  inorder_helper(node->right, out);
}

// recursive function (start from root)
int BSTree::get_total_search_time(Node* node)
{
  if (node != nullptr) {
    return node->search_time +
      get_total_search_time(node->left) +
      get_total_search_time(node->right);
  }
  return 0;
}

// 
float BSTree::get_average_search_time()
{
  int total_search_time = get_total_search_time(root);
  if (total_search_time == 0)
    return -1; // special case
	
  return ((float)total_search_time)/size;
}


///////////////////////////////////
//
//     FUNCTIONS TO IMPLEMENT
//
///////////////////////////////////

// These are the functions you should implement
// Feel free to call the functions above or
// create new helper functions

// copy constructor
BSTree::BSTree(const BSTree& other) : size(other.size), root(nullptr) 
{
  copy_helper(root, other.root);
}

// copy assignment
BSTree& BSTree::operator=(const BSTree& other)
{
  if(this == &other){
    return *this;
  }

  delete_helper(root);
  root = nullptr;
  size = 0;

  copy_helper(root, other.root);
  size = other.size;

  return *this;
}

// move constructor
BSTree::BSTree(BSTree&& other) : size(other.size), root(other.root) 
{
  other.size = 0;
  other.root = nullptr;
}

// move assignment
BSTree& BSTree::operator=(BSTree&& other)
{
  if(this == &other){
    return *this;
  }

  delete_helper(root);
  root = other.root;
  size = other.size;

  other.size = 0;
  other.root = nullptr;

  return *this;
}


// destructor
BSTree::~BSTree()
{
    // Make sure to call delete on every node of the tree
    // You can use a recursive helper function to do this
    delete_helper(root);
    size = 0;
}

Node* BSTree::insert(int val)
{
  // insert a node into the tree:
  // first find where the node should go
  // then modify pointers to insert your new node 
  int cost = 1;
  size++;
  return insert_helper(root, val, cost);
}

Node* BSTree::search(int val)
{
  // recursively search down the tree to find 
  // the node that contains val,
  // if you don't find anything return nullptr

  return search_helper(root, val);
}

void BSTree::update_search_times()
{
  // update the search times of all nodes at once
  
  queue<Node*> q;
  q.push(root);
  int elementsInLevel = 1;
  bool noNullChild = false;
  int searchCost = 1;

  while(elementsInLevel > 0){ // bfs modified from print_level_by_level()'s implementation from assignment handout hints (not perfect adding nullptrs)
      Node* n = q.front();q.pop();elementsInLevel--; // dequeue() isnt a thing but this does the same, getting the value at the front of then removing 
      
      if(n != nullptr)
      {
        n->search_time = searchCost;

        // enqueue children of n to queue
        q.push(n->left);q.push(n->right); // queue is of node ptr so nullptr can be added
        if(n->left != nullptr || n->right != nullptr){noNullChild = true;} // atleast one child is not null
      }
      else
      {
        q.push(nullptr);q.push(nullptr);
      }

      if(elementsInLevel == 0)
      {
        searchCost++;
        if(noNullChild)
        {
          noNullChild = false;
          elementsInLevel = q.size();
        }
      }

    }
}

void BSTree::inorder(ostream& out)
{
  // Print tree in infix order.

  inorder_helper(root, out);
}


void BSTree::print_level_by_level(ostream& out)
{
    /* Print the tree using a BFS so that each level 
       contains the values for this level of the tree.
       Use . to mark empty positions. 
    
       If the tree looks like this:

              4
	    2   6
           1   5 7
                  9

       it should output:

       4[1]
       2[2] 6[2]
       1[3] . 5[3] 7[3]
       . . . . . . . 9[4]

       It might be helpful to do this part with the 
       std::queue data structure.
       HINT: the Nth level contains 2^(N-1) nodes 
       (with a value or with an . (dot)). 
    
       Watch out for nodes like the left child of 6 above, 
       and print the descendents of an empty node also as empty.  
       You can use operator<< to print nodes in the format 
       shown.
    */
    queue<Node*> q;
    q.push(root);
    int elementsInLevel = 1;
    bool noNullChild = false;

    while(elementsInLevel > 0){// bfs implementation from assignment handout hints
      Node* n = q.front();q.pop();elementsInLevel--; // dequeue() isnt a thing but this does the same
      
      if(n != nullptr)
      {
        out << *n; // add node to output

        // enqueue children of n to queue
        q.push(n->left);q.push(n->right); // queue is of node ptr so nullptr can be added
        if(n->left != nullptr || n->right != nullptr){noNullChild = true;} // atleast one child is not null
      }
      else
      {
        out << ".";q.push(nullptr);q.push(nullptr);
      }

      if(elementsInLevel == 0)
      {
        out << " \n";
        if(noNullChild)
        {
          noNullChild = false;
          elementsInLevel = q.size();
        }
      }
      else{
        out << " ";
      }

    }
}
