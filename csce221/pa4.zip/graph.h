#ifndef GRAPH_H
#define GRAPH_H

#include <vector>
#include <unordered_map>
#include <list>
#include <queue>
#include <sstream>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

// try not to change it 
template <class T>
struct Vertex {
  T label; // unique int/string for a vertex
  vector<T> adj_list;
  int indegree; // Part 2: number of nodes pointing in
  int top_num; // Part 2: topological sorting number
  Vertex() {}  // default constructor
  Vertex(T l) : label(l), adj_list(), indegree(0), top_num(0) {} //Part 1
};

// optional, but probably helpful (comment it out if not used)
template <class T>
ostream& operator<<(ostream &o, Vertex<T> v){
  o << v.label << " :";
  for (const auto& adj : v.adj_list) {
    o << ' ' << adj;
  }
  return o;
};

template <class T>
class Graph {
private:
  //c++ STL hash table
  unordered_map<T, Vertex<T>> node_set;
  bool indegrees_computed, has_cycles, top_sort_done; //optional
  //Use other data fields if needed
  
public:
  Graph() : node_set(), indegrees_computed(false),
	    has_cycles(false), top_sort_done(false) {}; 
  ~Graph() {}; //No modification needed to destructor.

  // build a graph - refer the instructions PDF for more information.
  void buildGraph(istream &input){
    T label, adj;
    string adjStr;

    while(input.good())
    {
      input >> label;  // reads the label of the vertex of the current line, which is the first of the line

      // returns pair whose type is pair<unordered_map<T, Vertex<T>>::iterator, bool> for the currently inserted object
      auto pair = node_set.insert(make_pair(label, Vertex<T>(label)));

      Vertex<T>& v = pair.first->second; // v is a reference to the Vertex<T> created earlier

      getline(input, adjStr); // reads the elements in the rest of the line
      stringstream ss(adjStr);

      while (ss >> adj)
      {
        v.adj_list.push_back(adj);
      }
      adjStr = "";ss.clear();

    }

  }

  // display the graph into ostream
  // refer the instructions PDF for more information.
  void displayGraph(ostream& o){
    for(auto & node : node_set) {
      o << node.first << ": ";
      for(T i:node.second.adj_list) {
        o << i << " ";
      }
      o << endl;
    }
  } // Part 1

  //return the vertex at label, else throw any exception
  // refer the instructions PDF for more information.
  Vertex<T> at(T label){return node_set.at(label);} // returns std::out_of_range If no such data is present anyway?
  

  //return the graph size (number of verticies)
  int size(){return node_set.size();}

  // topological sort
  // return true if successful, false on failure (cycle)
  bool topological_sort(){
    queue<Vertex<T>> q;while (q.size()>0){q.pop();}
    unsigned int counter = 0;

    if(!indegrees_computed){compute_indegree();}

    for(auto& v: node_set){if(v.second.indegree == 0){q.push(v.second);}}

    while(q.size() > 0)
    {
      Vertex<T> v = q.front();q.pop(); // v is a copy not a reference 
      v.top_num = ++counter;

      for(T a: v.adj_list) // "for each vertex w adjacent to v"
      {
        Vertex<T>& w = node_set.at(a); 
        if(--w.indegree == 0){q.push(w);}
      }

      node_set.at(v.label) = v; // update node v in the node set

    }

    if(counter != node_set.size()){has_cycles = true;return false;}
    top_sort_done = true; return true;
    
  }; // Part 2

  // find indegree
  void compute_indegree(){
    for(auto& v: node_set){v.second.indegree = 0;} // set all indegrees to zero


    for(auto& v: node_set) // update indegree of all vertices
    {
      for(T a: v.second.adj_list) // "for each vertex w adjacent to v"
      {
        Vertex<T>& w = node_set.at(a); 
        w.indegree++; // increment indegree
      }
    }

    indegrees_computed = true;
  }; // Part 2

  // print topological sort into ostream
  // if addNewline is true insert newline into stream
  void print_top_sort(ostream& o, bool addNewline=true)
  {
    if (!top_sort_done && !topological_sort()) {
      throw invalid_argument("Graph has cycle(s)"
			     " and cannot be sorted topologically");
    }

    vector<T> vec(this->size());
    for (const auto& vertex : node_set) {
      vec.at(vertex.second.top_num - 1) = vertex.second.label;
    }

    for (const auto& label : vec) {
      o << label << ' ';
    }

    if(addNewline) {
      o << '\n';
    }
  }; // Part 2
};

#endif
