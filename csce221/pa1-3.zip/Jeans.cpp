#include "Jeans.h"

// implementation of the class Jeans

// default constructor
Jeans::Jeans() : color((Jeans_colors)(rand() % 4)), size((Jeans_sizes)(rand() % 4)) {}

// constructor
Jeans::Jeans(Jeans_colors c, Jeans_sizes s) : color(c), size(s) {}

// method functions
Jeans_colors Jeans::get_color() const
{
    return color;
}

Jeans_sizes Jeans::get_size() const
{
    return size;
}

bool Jeans::operator==(const Jeans& jn)
{
    return (this->color == jn.get_color()) && (this->size == jn.get_size());
}

// output
ostream& operator<<(ostream& os, const Jeans& jn)
{
    const std::string COLOR_STRINGS[4] = {"white", "black", "blue", "grey"};
    const std::string SIZE_STRINGS[4] = {"small", "medium", "large", "xlarge"};

    os << "(" << COLOR_STRINGS[(int)jn.get_color()] << ", " << SIZE_STRINGS[(int)jn.get_size()] << ")";
    return os;
}


istream &operator>>(istream &is, CollectionJN &c)
{
    const std::string COLOR_STRINGS[4] = {"white", "black", "blue", "grey"};
    const std::string SIZE_STRINGS[4] = {"small", "medium", "large", "xlarge"};

    std::string color;
    std::string size;
    Jeans_colors color_enum;
    Jeans_sizes size_enum;
    Jeans jn;

    while(is.good()){
        is >> color;
        is >> size;

        color_enum = Jeans_colors(0);
        size_enum = Jeans_sizes(0);

        for(int i = 0;i<4;++i){
            if (color == COLOR_STRINGS[i]){
                color_enum = (Jeans_colors)(i);
            }
        }

        for(int i = 0;i<4;++i){
            if(size == SIZE_STRINGS[i]){
                size_enum = (Jeans_sizes)(i);
            }
        }
    

        jn = Jeans(color_enum, size_enum);
        c.insert_item(jn);
    }

    return is;
}