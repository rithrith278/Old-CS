#include "Stress_ball.h"



// default constructor
Stress_ball::Stress_ball() : color((Stress_ball_colors)(rand() % 4)), size((Stress_ball_sizes)(rand() % 3)) {}

// constructor
Stress_ball::Stress_ball(Stress_ball_colors c, Stress_ball_sizes s) : color(c), size(s) {}

// method functions
Stress_ball_colors Stress_ball::get_color() const
{
    return color;
}

Stress_ball_sizes Stress_ball::get_size() const
{
    return size;
}

bool Stress_ball::operator==(const Stress_ball& sb)
{
    return (this->color == sb.get_color()) && (this->size == sb.get_size());
}

// output
ostream& operator<<(ostream& os, const Stress_ball& sb)
{
    std::string COLOR_STRINGS[4] = {"red", "blue", "green", "yellow"};
    std::string SIZE_STRINGS[3] = {"small", "medium", "large"};

    os << "(" << COLOR_STRINGS[(int)sb.get_color()] << ", " << SIZE_STRINGS[(int)sb.get_size()] << ")";
    return os;
}

istream &operator>>(istream &is, CollectionSB &c)
{

    std::string COLOR_STRINGS[4] = {"red", "blue", "green", "yellow"};
    std::string SIZE_STRINGS[3] = {"small", "medium", "large"};



    std::string color;
    std::string size;
    Stress_ball_colors color_enum;
    Stress_ball_sizes size_enum;
    Stress_ball sb;

    while(is.good()){
        is >> color;
        is >> size;

        color_enum = Stress_ball_colors(0);
        size_enum = Stress_ball_sizes(0);

        for(int i = 0;i<4;++i){
            if (color == COLOR_STRINGS[i]){
                color_enum = (Stress_ball_colors)(i);
            }
        }

        for(int i = 0;i<3;++i){
            if(size == SIZE_STRINGS[i]){
                size_enum = (Stress_ball_sizes)(i);
            }
        }
    

        sb = Stress_ball(color_enum, size_enum);
        c.insert_item(sb);
    }

    return is;
}

