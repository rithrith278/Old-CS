#ifndef COLLECTION_H
#define COLLECTION_H

#include <string>
#include <iostream>

using namespace std;

enum class Sort_choice{bubble_sort, insertion_sort, selection_sort, quick_sort, merge_sort};

// class template definition
template <typename Obj, typename F1, typename F2>
class Collection {

    private:
    Obj* array;
    int size;
    int capacity;
    void resize()
    {
    // new larger array 
    Obj *resized_array = new Obj[2 * capacity];

    // copy old array to new array
    for (int i = 0; i < capacity; ++i)
    {
        resized_array[i] = array[i];
    }

    // delete old array and make new array the collection array
    delete[] array;
    array = resized_array;
    resized_array = nullptr;
    capacity *= 2;
    }

    public:

    // default constructor
    Collection() : array(nullptr), size(0), capacity(0) {}


    // constructor
    Collection(int cap) : array(new Obj[cap]), size(0), capacity(cap) {}


    // lab3 constructor
    Collection(Obj* a, int s, int c) : array(a), size(s), capacity(c) {}



    // copy constructor
    Collection(const Collection<Obj, F1, F2> &c) : array(nullptr), size(c.size), capacity(c.capacity)
    {

        if (c.array != nullptr)
        { // deep copy non empty collection's array
            array = new Obj[capacity];

            for (int i = 0; i < capacity; ++i)
            {
                array[i] = c[i];
            }
        }
        else{
            size = 0;
            capacity = 0;
        }
    }


    // copy assignment constructor
    Collection& operator=(const Collection<Obj, F1, F2> &c)
    {
        if (this == &c) // self assignment check
        {
            return *this;
        }

        size = c.size;
        capacity = c.capacity;

        delete[] array;
        array = new Obj[capacity];

        for (int i = 0; i < capacity; ++i)
        {
            array[i] = c[i];
        }

        return *this;
    }


    // destructor
    ~Collection()
    {
        size = 0;
        capacity = 0;
        delete[] array;
        array = nullptr;
    }


    // move assignment constructor
    Collection(Collection<Obj, F1, F2> &&c) : array(c.array), size(c.size), capacity(c.capacity)
    {
        c.array = nullptr;
        c.size = 0;
        c.capacity = 0;
    }


    // move assignment operator
    Collection& operator=(Collection<Obj, F1, F2> &&c)
    {
        if (this == &c) // self assignemnt check
        {
            return *this;
        }

        array = c.array;
        size = c.size;
        capacity = c.capacity;

        c.array = nullptr;
        c.size = 0;
        c.capacity = 0;

        return *this;
    }
    


    // get methods
    Obj *get_array() const { return array; }
    int get_array_size() const { return size; }
    int get_array_capacity() const { return capacity; }



    // insert item to collection
    void insert_item(const Obj &t)
    {
        if(array == nullptr) // empty collection from default constructor or make_empty(); size is already 0
        { 
            capacity = 1;
            array = new Obj[capacity];
        }

        if (size == capacity) // collection is full - resize array before insert - size not affected
        {
            resize();
        }

        array[size] = t; // insert item at position size 

        size++;
    }


    // check if collection contains a specific item
    bool contains(const Obj& t) const
    {
        for (int i = 0; i < size; ++i)
        {
            if (array[i] == t)
            {
                return true;
            }
        }
        return false;
    }


    // removes a random item from the collection
    Obj remove_any_item()
    {
        // check and exception for empty array
        if(is_empty()){
            throw "empty collection";
        }

        // pick random object in collection
        Obj chosen_object = array[(rand() % size)];

        // remove chosen object from collection
        remove_this_item(chosen_object);

        // return the chosen object
        return chosen_object;
    }


    // removes the first instance of a specific item from the collection
    void remove_this_item(const Obj &t)
    {
        // check and exception for empty array
        if(is_empty()){
            throw "empty collection";
        }

        for (int i = 0; i < size; ++i) // find item
        {
            if (array[i] == t) // item is found
            {
                // move array elements positioned past item to the previous position effectively deleting the item
                for (int j = i + 1; j < size; ++j) 
                {
                    array[j-1] = array[j];
                }

                size--; // decrement size
                break;
            }
        }
    }


    // empty the collection
    void make_empty()
    {
        delete[] array;
        size = 0;
        capacity = 0;
        array = nullptr;
    }


    // check if collection is empty
    bool is_empty() const
    {
        return size == 0;
    }


    // return the number of items in the collection
    int total_items() const
    {
        return size;
    }


    // return the number of items in the collection of a specified item color(enum class F1)
    int total_items(F1 c) const
    {
        int color_count = 0;

        for (int i = 0; i < size; ++i)
        {
            if (array[i].get_color() == c)
            {
                color_count++;
            }
        }
        return color_count;
    }


    // return the number of items in the collection of a specified item size(enum class F2)
    int total_items(F2 s) const
    {
        int size_count = 0;

        for (int i = 0; i < size; ++i)
        {
            if (array[i].get_size() == s)
            {
                size_count++;
            }
        }
        return size_count;
        
    }


    // print all items in list
    void print_items() const
    {
        for (int i = 0; i < size; ++i)
        {
            cout << array[i] << endl;
        }
    }


    // collection [] operator
    Obj& operator[](int i)
    {
        return array[i];
    }


    // collection const [] operator
    const Obj& operator[](int i) const
    {
        return array[i];
    }

};


// output operator
template <typename Obj, typename F1, typename F2>
ostream& operator<<(ostream& os, const Collection<Obj, F1, F2>& c)
{
    int s = c.get_array_size();
    for(int i = 0; i < s; ++i){
        os << c[i];
    }
    return os;
}


// make a new collection from the union of two collections
template <typename Obj, typename F1, typename F2>
Collection<Obj, F1, F2> make_union(const Collection<Obj, F1, F2> &c1, const Collection<Obj, F1, F2> &c2)
{ 
    Collection<Obj, F1, F2> c3;

    for(int i = 0;i<c1.get_array_size();++i){
        c3.insert_item(c1[i]);
    }

    for(int i = 0;i<c2.get_array_size();++i){
        c3.insert_item(c2[i]);
    }
    
    return c3;
}


// swap two collections
template <typename Obj, typename F1, typename F2>
void swap(Collection<Obj, F1, F2> &c1, Collection<Obj, F1, F2> &c2)
{
    Collection<Obj, F1, F2> temp(std::move(c1));
    c1 = std::move(c2);
    c2 = std::move(temp);
}


// bubble sort collection by size
template <typename Obj, typename F1, typename F2>
void bubble_sort(Collection<Obj, F1, F2> &c)
{
    bool swapped;
    Obj temp;
    for(int i = 1;i < c.get_array_size();++i){
        swapped = false;

        for(int j = 0;j < c.get_array_size() - i;++j){
            if(c[j+1].get_size() < c[j].get_size()){
                temp = c[j+1];
                c[j+1] = c[j];
                c[j] = temp;
                swapped = true;
            }
        }

        if(!swapped){
            break;
        }
    }
}


// insertion sort collection by size
template <typename Obj, typename F1, typename F2>
void insertion_sort(Collection<Obj, F1, F2> &c)
{
    Obj temp;
    int j;
    for(int i=1;i<c.get_array_size();++i){
        temp = c[i];
        j = i;

        for(;j > 0 && temp.get_size() < c[j-1].get_size();j--){
            c[j] = c[j-1];
        }
        c[j] = temp;
    }
}


// selection sort collection by size
template <typename Obj, typename F1, typename F2>
void selection_sort(Collection<Obj, F1, F2> &c)
{
    Obj temp;
    int n = c.get_array_size();
    F2 s;
    int x = 0;
    int i = 0;

    while(i < n-1){
        s = (F2)x;

        for(int j = i+1;j<n;++j){
            if(c[j].get_size() == s){
                temp = c[i];
                c[i] = c[j];
                c[j] = temp;
                i+=1;
            }
        }
        x++;
    }
}



// sort collection in increasing order of size using specified sorting algorithm
template <typename Obj, typename F1, typename F2>
inline void sort_by_size(Collection<Obj, F1, F2> &c, Sort_choice sort)
{
    switch (sort)
    {
    case Sort_choice::bubble_sort:
        bubble_sort(c);
        break;

    case Sort_choice::insertion_sort:
        insertion_sort(c);
        break;

    case Sort_choice::selection_sort:
        selection_sort(c);
        break;

    default:
        break;
    }
}

#endif