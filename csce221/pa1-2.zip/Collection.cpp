#include "Collection.h"
#include "Stress_ball.h"

// implement the class Collection functions
// ...

// default constructor - size, capacity 0 and array nullptr
Collection::Collection() : array(nullptr), size(0), capacity(0) {}

// constructor
Collection::Collection(int cap) : array(new Stress_ball[cap]), size(0), capacity(cap) {}

// copy constructor
Collection::Collection(const Collection &c) : array(nullptr), size(c.size), capacity(c.capacity)
{

    if (c.array != nullptr)
    { // deep copy non empty collection's array
        array = new Stress_ball[capacity];

        for (int i = 0; i < capacity; ++i)
        {
            array[i] = c[i];
        }
    }
    else{
        size = 0;
        capacity = 0;
    }
}

// copy assignment
Collection &Collection::operator=(const Collection &c)
{
    if (this == &c)
    {
        return *this;
    }

    size = c.size;
    capacity = c.capacity;

    delete[] array;
    array = new Stress_ball[capacity];

    for (int i = 0; i < capacity; ++i)
    {
        array[i] = c[i];
    }

    return *this;
}

// resize - double collection's array's capacity
void Collection::resize()
{
    Stress_ball *resized_array = new Stress_ball[2 * capacity];

    for (int i = 0; i < capacity; ++i)
    {
        resized_array[i] = array[i];
    }

    delete[] array;
    array = resized_array;
    resized_array = nullptr;
    capacity *= 2;
}

// destructor
Collection::~Collection()
{
    size = 0;
    capacity = 0;
    delete[] array;
    array = nullptr;
}

// move constructor
Collection::Collection(Collection &&c) : array(c.array), size(c.size), capacity(c.capacity)
{
    c.array = nullptr;
    c.size = 0;
    c.capacity = 0;
}

// move assignment
Collection &Collection::operator=(Collection &&c)
{
    if (this == &c)
    {
        return *this;
    }

    array = c.array;
    size = c.size;
    capacity = c.capacity;

    c.array = nullptr;
    c.size = 0;
    c.capacity = 0;

    return *this;
}

// insert
void Collection::insert_item(const Stress_ball &sb)
{
    if(array == nullptr){ // empty collection from default constructor or make_empty(); size is already 0
        capacity = 1;
        size = 0;
        array = new Stress_ball[1];
    }

    if (size == capacity) // collection is full
    {
        resize();
    }

    if(is_empty()){ // previous 2 cases or an empty collection with capacity > 0
        array[0] = sb;
    }
    else{
        array[size] = sb;
    }

    size++;
}

// contains
bool Collection::contains(const Stress_ball &sb) const
{
    for (int i = 0; i < size; ++i)
    {

        if (array[i] == sb)
        {
            return true;
        }
    }
    return false;
}

// remove any random item from colection
Stress_ball Collection::remove_any_item()
{
    // TODO: exception for empty array
    if(is_empty()){
        throw "empty collection";
    }


    // pick random element
    Stress_ball chosen_stress_ball = array[(rand() % size)];

    // shift next elements
    remove_this_item(chosen_stress_ball);

    // return chosen element
    return chosen_stress_ball;
}

// remove stressball item
void Collection::remove_this_item(const Stress_ball &sb)
{
    // TODO: exception for empty array here also
    if(is_empty()){
        throw "empty collection";
    }

    for (int i = 0; i < size; ++i)
    {

        if (array[i] == sb)
        {

            for (int j = i + 1; j < size; ++j)
            {
                array[j-1] = array[j];
            }
            size--;
            break;
        }
    }
}

void Collection::make_empty()
{
    delete[] array;
    size = 0;
    capacity = 0;
    array = nullptr;
}

bool Collection::is_empty() const
{
    return size == 0;
}

int Collection::total_items() const
{
    return size;
}

int Collection::total_items(Stress_ball_sizes s) const
{
    int size_count = 0;

    for (int i = 0; i < size; ++i)
    {
        if (array[i].get_size() == s)
        {
            size_count++;
        }
    }
    return size_count;
}

int Collection::total_items(Stress_ball_colors c) const
{
    int color_count = 0;

    for (int i = 0; i < size; ++i)
    {
        if (array[i].get_color() == c)
        {
            color_count++;
        }
    }
    return color_count;
}

void Collection::print_items() const
{
    for (int i = 0; i < size; ++i)
    {
        cout << array[i] << endl;
    }
}

// operator[] and const overload
Stress_ball &Collection::operator[](int i)
{
    return array[i];
}

const Stress_ball &Collection::operator[](int i) const
{
    return array[i];
}

Stress_ball_colors color_enum_from_string(string s){
    std::string colorStrs[4] = {"red", "blue", "green", "yellow"};
    for(int i = 0;i<4;++i){
        if(s == colorStrs[i]){
            return (Stress_ball_colors)(i);
        }
    }
    return Stress_ball_colors(0);
}

Stress_ball_sizes size_enum_from_string(string s){
    std::string sizeStrs[3] = {"small", "medium", "large"};
    for(int i = 0;i<3;++i){
        if(s == sizeStrs[i]){
            return (Stress_ball_sizes)(i);
        }
    }
    return Stress_ball_sizes(0);

}

istream &operator>>(istream &is, Collection &c)
{
    string color;
    string size;
    Stress_ball_colors color_enum;
    Stress_ball_sizes size_enum;
    Stress_ball sb;

    while(is.good()){
        // read color and size strings
        is >> color;
        is >> size;

        color_enum = color_enum_from_string(color);
        size_enum = size_enum_from_string(size);

        sb = Stress_ball(color_enum, size_enum);

        c.insert_item(sb);
    }

    return is;
}

ostream &operator<<(ostream &os, const Collection &c)
{
    // TODO: insert return statement here
    for(int i = 0;i<c.get_array_size();i++){
        os << c[i] << '\n';
    }
    return os;
}

Collection make_union(const Collection &c1, const Collection &c2)
{
    Collection c3;

    for(int i = 0;i<c1.get_array_size();++i){
        c3.insert_item(c1[i]);
    }

    for(int i = 0;i<c2.get_array_size();++i){
        c3.insert_item(c2[i]);
    }
    
    return c3;
}

void swap(Collection &c1, Collection &c2)
{
    Collection temp(std::move(c1));
    c1 = std::move(c2);
    c2 = std::move(temp);

}

void bubble_sort(Collection &c){
    bool swapped;
    Stress_ball temp;
    for(int i = 1;i < c.get_array_size();++i){
        swapped = false;

        for(int j = 0;j < c.get_array_size() - i;++j){
            if(c[j+1].get_size() < c[j].get_size()){
                temp = c[j+1];
                c[j+1] = c[j];
                c[j] = temp;
                swapped = true;
            }
        }

        if(!swapped){
            break;
        }
    }


    
}

void insertion_sort(Collection &c){
    Stress_ball temp;
    int j;
    for(int i=1;i<c.get_array_size();++i){
        temp = c[i];
        j = i;

        for(;j > 0 && temp.get_size() < c[j-1].get_size();j--){
            c[j] = c[j-1];
        }
        c[j] = temp;
    }
}

void selection_sort(Collection &c){

}

void sort_by_size(Collection &c, Sort_choice sort)
{
    switch (sort)
    {
    case Sort_choice::bubble_sort:
        bubble_sort(c);
        break;

    case Sort_choice::insertion_sort:
        insertion_sort(c);
        break;

    case Sort_choice::selection_sort:
        selection_sort(c);
        break;
    
    default:
        break;
    }

}
