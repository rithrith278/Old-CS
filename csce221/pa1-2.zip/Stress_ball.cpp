// write your code in this file

#include "Stress_ball.h"


// default constructor
Stress_ball::Stress_ball() : color((Stress_ball_colors)(rand() % 4)), size((Stress_ball_sizes)(rand() % 3)) {}

// constructor
Stress_ball::Stress_ball(Stress_ball_colors c, Stress_ball_sizes s) : color(c), size(s) {}

// method functions
Stress_ball_colors Stress_ball::get_color() const
{
    return color;
}

Stress_ball_sizes Stress_ball::get_size() const
{
    return size;
}

bool Stress_ball::operator==(const Stress_ball& sb)
{
    return (this->color == sb.get_color()) && (this->size == sb.get_size());
}

ostream& operator<<(ostream& os, const Stress_ball& sb)
{
    // get color and size as strings from enum values
    std::string colorStrs[4] = {"red", "blue", "green", "yellow"};
    std::string sizeStrs[3] = {"small", "medium", "large"};
    int colorInt = (int)sb.get_color();
    int sizeInt = (int)sb.get_size();
    
    os << "(" << colorStrs[colorInt] << ", " << sizeStrs[sizeInt] << ")";
    return os;
}
