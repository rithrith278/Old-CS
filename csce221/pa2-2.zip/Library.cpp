#include "Library.h"
#include "TemplatedDLList.h"
#include <fstream>
#include <string>

// Searches for a title in the database and returns vector of matching records
std::vector<Record> Library::search(std::string title)
{
    vector<Record> results;
    int dbindex = ((int)title.at(0))-65;
    DLListNode<Record>* node = (book_db.at(dbindex)).first_node();

    while(node != (book_db.at(dbindex)).after_last_node()){
        if(node->obj.get_title() == title){
            results.push_back(node->obj);
        }
        node = node->next;
    }

    return results;
}

// Imports records from a file.  Does not import duplicates.
// Returns the number of records added to the database
int Library::import_database(std::string filename)
{
    int count;
    ifstream ifs;
    Record r;
    ifs.open(filename);

    if(!ifs.is_open()){return 0;}

    while(ifs.good()){
        ifs >> r;
        if(add_record(r)){
            count++;
        }
    }
    ifs.close();
    return count;
}

// Exports the current database to a file
// Returns the number of records exported
int Library::export_database(std::string filename)
{
    return 0;
}

// Prints out every book in the library
void Library::print_database()
{
    for(int i = 0;i<book_db.size();++i){
        DLListNode<Record>* node = (book_db.at(i)).first_node();
        while(node != (book_db.at(i)).after_last_node()){
            cout << node->obj << endl;
            node = node->next;
        }
    }
}

// Adds record to database, avoid complete duplicates
bool Library::add_record(Record book)
{
    if(search(book.get_title()).size() != 0){return false;}

    int dbindex = ((int)book.get_title().at(0))-65;
    DLListNode<Record>* node = (book_db.at(dbindex)).first_node();

    
    while(node != (book_db.at(dbindex)).after_last_node()->prev){
        if(node->next->obj.get_title() > (book.get_title())){
            book_db.at(dbindex).insert_after(*node, book);
            return true;
        }
        node = node->next;
    }
    book_db.at(dbindex).insert_last(book);
    
    return true;

}

// Deletes a record from the database
void Library::remove_record(Record book)
{
    for(int i = 0;i<book_db.size();++i){
        DLListNode<Record>* node = (book_db.at(i)).first_node();
        if(node->obj.get_title().at(0) == book.get_title().at(0)){
            while(node != (book_db.at(i)).after_last_node()->prev){
                if(node->next->obj == book){
                    book_db.at(i).remove_after(*node);
                }
                node = node->next;
            }
        }
    }
}

// Prompts user for yes or no and returns choice Y or N
char Library::prompt_yes_no()
{
    return prompt_string("Yes or no? (Y/N): ").at(0);
}

// Given a vector of menu options returns index of choice
int Library::prompt_menu(std::vector<std::string> prompts)
{
    // Print out prompt statements
    for (int i = 0; i < prompts.size(); i++)
    {
        std::cout << "\t" << (i + 1) << ". " << prompts.at(i) << std::endl;
    }

    return (std::stoi(prompt_string("Enter option: ")) - 1);
}

// Prompts user for a new record
Record Library::prompt_record()
{
    std::string title = prompt_title();
    std::string author = prompt_string("Enter author: ");
    std::string ISBN = prompt_string("Enter ISBN: ");
    std::string year = prompt_string("Enter year: ");
    std::string edition = prompt_string("Enter edition: ");

    Record rtn;
    rtn.set_title(title);
    rtn.set_author(author);
    rtn.set_ISBN(ISBN);
    rtn.set_year(year);
    rtn.set_edition(edition);

    return rtn;
}

// Prompts for a valid title
std::string Library::prompt_title()
{
    return prompt_string("Enter title (starts with capital letter): ");
}

// Prompts for a valid string
std::string Library::prompt_string(std::string prompt)
{
    std::cout << prompt;
    std::string answer;
    getline(cin, answer);

    return answer;
}