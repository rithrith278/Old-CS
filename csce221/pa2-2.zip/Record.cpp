//implementation of record class

#include "Record.h"

void Record::set_title(string t) { title = t; }

void Record::set_author(string a){author = a;}

void Record::set_ISBN(string i){ISBN = i;}

void Record::set_year(string y){year = y;}

void Record::set_edition(string e){edition = e;}

string Record::get_title() const
{
    return title;
}

string Record::get_author() const
{
    return author;
}

string Record::get_ISBN() const
{
    return ISBN;
}

string Record::get_year() const
{
    return year;
}

string Record::get_edition() const
{
    return edition;
}

std::istream &operator>>(std::istream &is, Record &rec) // reads only one record from file
{
    string line;

    getline(is, line); // skip empty line before each record - also value of line get reassigned with each getline() call

    getline(is, line);
    rec.set_title(line);

    getline(is, line);
    rec.set_author(line);

    getline(is, line);
    rec.set_ISBN(line);

    getline(is, line);
    rec.set_year(line);

    getline(is, line);
    rec.set_edition(line);

    return is;
}

std::ostream &operator<<(std::ostream &os, Record &rec)
{
    os << rec.get_title() << "\n" << rec.get_author() << "\n" << rec.get_ISBN() << "\n" << rec.get_year() << "\n" << rec.get_edition() << "\n";
    return os; // same format as instructions doc
}

bool operator==(const Record &r1, const Record &r2) // return true if same title, author name, 
{
    return ((r1.get_author() == r2.get_author()) && (r1.get_title() == r2.get_title()) && (r1.get_ISBN() == r2.get_ISBN()));
}
