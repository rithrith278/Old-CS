// header file for the templated DLList

#ifndef TEMPLATEDDLLIST_H
#define TEMPLATEDDLLIST_H

#include <iostream>
#include <stdexcept>

using namespace std;

template <typename T>
class DLList; // class declaration (must be here)

// doubly linked list node
template <typename T>
struct DLListNode {
  T obj;
  DLListNode<T> *prev, *next;
  DLListNode(T e=T(), DLListNode *p=nullptr, DLListNode *n=nullptr):
    obj(e), prev(p), next(n) {}
};

// doubly linked list class
template <typename T>
class DLList {
private:
  DLListNode<T> header, trailer;
  
public:
  DLList() : header(), trailer()// default constructor
  {
    header.next = &trailer;
    trailer.prev = &header;
  }

  DLList(const DLList<T>& dll) : header(), trailer()// copy constructor
  {
    DLListNode<T> *dllNode = dll.first_node();
    DLListNode<T> *prevnode, *node = &header;

    while(dllNode != dll.after_last_node()){
        prevnode = node;
        node = node->next;

        node = new DLListNode<T>(dllNode->obj, prevnode, nullptr);
        prevnode->next = node;

        dllNode = dllNode->next;
    }

    node->next = &trailer;
    trailer.prev = node;
  }

  DLList(DLList<T>&& dll) // move constructor
  {
    header.next = dll.header.next;
    trailer.prev = dll.trailer.prev;

    if (header.next != &dll.trailer) {
        header.next->prev = &header;
        trailer.prev->next = &trailer;
    } else {
        header.next = &trailer;
        trailer.prev = &header;
    }

    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
  } 
  ~DLList() // destructor
  {
    while(!is_empty()){
        remove_first();
    }
  }

  DLList<T>& operator=(const DLList<T>& dll) // copy assignment operator
  {
    if(this == &dll){
        return *this;
    }

    while(!is_empty()){remove_first();}


    DLListNode<T>* currentnode = dll.header.next;
    while (currentnode != &dll.trailer) {
        insert_last(currentnode->obj);
        currentnode = currentnode->next;
    }

    return *this;
  } 
  DLList<T>& operator=(DLList<T>&& dll) // move assignment operator
  {
    if(this == &dll){
        return *this;
    }

    header.next = dll.header.next;
    trailer.prev = dll.trailer.prev;

    if (header.next != &trailer) {
        header.next->prev = &header;
        trailer.prev->next = &trailer;
    } 
    else {
        header.next = &trailer;
        trailer.prev = &header;
    }

    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;

    return *this;
  } 
  // return the pointer to the first node
  DLListNode<T> *first_node() const { return header.next; } 
  
  
  // return the pointer to the trailer
  const DLListNode<T> *after_last_node() const { return &trailer; }
  
  
  // return if the list is empty
  bool is_empty() const { return header.next == &trailer; }
  
  
  T first() const // return the first object
  {
    return header.next->obj;
  } 
  T last() const // return the last object
  {
    return trailer.prev->obj;
  } 
  void insert_first(T obj) // insert to the first node
  {
    DLListNode<T> *newNode = new DLListNode<T>(obj, &header, header.next);

    header.next->prev = newNode;
    header.next = newNode;
  } 
  T remove_first() // remove the first node
  {
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    DLListNode<T> *removeNode = header.next; // define a pointer to the first node 
    T returnObj = removeNode->obj; // get the first node's object to be returned

    // updates the header's next and second node's previous node pointers to connect to each other
    removeNode->next->prev = &header; // second node' previous node is now the header
    header.next = removeNode->next; // header's next node is the second node

    delete removeNode; // delete the first node from memory pointed to by removenode
    removeNode = nullptr;

    return returnObj;
  } 
  void insert_last(T obj) // insert to the last node
  {
    DLListNode<T> *newNode = new DLListNode<T>(obj, trailer.prev, &trailer);

    trailer.prev->next = newNode;
    trailer.prev = newNode;
  } 
  T remove_last() // remove the last node
  {
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    DLListNode<T> *removeNode = trailer.prev; // define a pointer to the last node 
    T returnObj = removeNode->obj; // get the last node's object

    removeNode->prev->next = &trailer;
    trailer.prev = removeNode->prev;

    delete removeNode;

    return returnObj;
  } 
  void insert_after(DLListNode<T> &p, T obj)
  {
    // node p can be any node in the list [header, trailer), we need to find it in the list so that the 
    DLListNode<T> *node = &header;
    DLListNode<T> *nextNode = header.next;
    DLListNode<T> *newNode = nullptr;

    while(node != &trailer){ // node iterates from header to the last element of the list to find node p

        if(node == &p){ // once node p is found, insert a new list node of obj between p and the node after
            newNode = new DLListNode<T>(obj, node, nextNode);

            node->next = newNode;
            nextNode->prev = newNode;

            break; // new obj inserted into DLL, no need to continue loop
        }

        node = nextNode;
        nextNode = nextNode->next;
    }
  } 
  void insert_before(DLListNode<T> &p, T obj)
  {
    DLListNode<T> *prevNode, *node = &header;
    DLListNode<T> *newNode = nullptr;

    while(node != &trailer){ // node iterates from header to the last element of the list to find node p
        prevNode = node;
        node = node->next;

        if(node == &p){
            newNode = new DLListNode<T>(obj, prevNode, node);

            node->prev = newNode;
            prevNode->next = newNode;

            break;
        }
    }
  }
  T remove_after(DLListNode<T> &p)
  {
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    T returnObj;
    DLListNode<T> *node = &header;
    DLListNode<T> *removeNode, *newNext;

    while(node->next != &trailer){
        if(node == &p){
            removeNode = node->next;
            newNext = removeNode->next;

            returnObj = removeNode->obj;

            delete removeNode;

            node->next = newNext;
            newNext->prev = node;
            break;
        }
        node = node->next;
    }

    return returnObj;
  } 
  T remove_before(DLListNode<T> &p)
  {
    if(is_empty()) {throw "Empty DLList";} // empty DLL check
    
    T returnObj;
    DLListNode<T> *node = header.next;
    DLListNode<T> *removeNode, *newPrev;

    while(node != &trailer){
        if(node == &p){
            removeNode = node->prev;
            newPrev = removeNode->prev;

            returnObj = removeNode->obj;

            delete removeNode;

            node->prev = newPrev;
            newPrev->next = node;
            break;
        }
        node = node->next;
    }


    return returnObj;
  } 
};

// output operator
template <typename T>
ostream& operator<<(ostream& out, const DLList<T>& dll)
{
  DLListNode<T> *node = dll.first_node();

    while(node != dll.after_last_node()){
        out << node->obj;
        if(node->next != dll.after_last_node()){out << ", ";}
        node = node->next;
    }
    return out;
} 

#endif
