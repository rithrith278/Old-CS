// implementation of the DLList class

#include "DLList.h"

// default constructor - empty list
DLList::DLList() : header(0), trailer(0)
{
    header.next = &trailer;
    trailer.prev = &header;
}

// copy constructor
DLList::DLList(const DLList &dll) : header(0), trailer(0)
{
    DLListNode *dllNode = dll.first_node();
    DLListNode *prevnode, *node = &header;

    while(dllNode != dll.after_last_node()){
        prevnode = node;
        node = node->next;

        node = new DLListNode(dllNode->obj, prevnode, nullptr);
        prevnode->next = node;

        dllNode = dllNode->next;
    }

    node->next = &trailer;
    trailer.prev = node;
}

// move constructor
DLList::DLList(DLList &&dll)
{
    header.next = dll.header.next;
    trailer.prev = dll.trailer.prev;

    if (header.next != &dll.trailer) {
        header.next->prev = &header;
        trailer.prev->next = &trailer;
    } else {
        header.next = &trailer;
        trailer.prev = &header;
    }

    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
}

// destructor
DLList::~DLList() 
{
    DLListNode *first = header.next;

    while(first != &trailer){
        header.next = first->next;
        first->next->prev = &header;
        
        delete first;
        first = header.next;
    }
}

// copy assignment operator
DLList &DLList::operator=(const DLList &dll)
{
    if(this == &dll){
        return *this;
    }

    while(!is_empty()){remove_first();}


    DLListNode* currentnode = dll.header.next;
    while (currentnode != &dll.trailer) {
        insert_last(currentnode->obj);
        currentnode = currentnode->next;
    }

    return *this;
}

// move assignment operator
DLList &DLList::operator=(DLList &&dll)
{

    if(this == &dll){
        return *this;
    }

    header.next = dll.header.next;
    trailer.prev = dll.trailer.prev;

    if (header.next != &trailer) {
        header.next->prev = &header;
        trailer.prev->next = &trailer;
    } else {
        header.next = &trailer;
        trailer.prev = &header;
    }

    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;

    return *this;
}


DLListNode *DLList::first_node() const
{
    return header.next;
}

const DLListNode *DLList::after_last_node() const
{
    return &trailer;
}

bool DLList::is_empty() const {return header.next == &trailer;}

int DLList::first() const {return header.next->obj;} // returns 0 on empty list

int DLList::last() const {return trailer.prev->obj;} // returns 0 on empty list

void DLList::insert_first(int obj)
{
    DLListNode *newNode = new DLListNode(obj, &header, header.next);

    header.next->prev = newNode;
    header.next = newNode;
}

int DLList::remove_first()
{
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    DLListNode *removeNode = header.next; // define a pointer to the first node 
    int returnObj = removeNode->obj; // get the first node's object to be returned

    // updates the header's next and second node's previous node pointers to connect to each other
    removeNode->next->prev = &header; // second node' previous node is now the header
    header.next = removeNode->next; // header's next node is the second node

    delete removeNode; // delete the first node from memory pointed to by removenode
    removeNode = nullptr;

    return returnObj;
}

void DLList::insert_last(int obj)
{
    DLListNode *newNode = new DLListNode(obj, trailer.prev, &trailer);

    trailer.prev->next = newNode;
    trailer.prev = newNode;
}

int DLList::remove_last()
{
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    DLListNode *removeNode = trailer.prev; // define a pointer to the last node 
    int returnObj = removeNode->obj; // get the last node's object

    removeNode->prev->next = &trailer;
    trailer.prev = removeNode->prev;

    delete removeNode;

    return returnObj;
}

void DLList::insert_after(DLListNode &p, int obj) // insert a new node containing obj after node p of the list
{
    // node p can be any node in the list [header, trailer), we need to find it in the list so that the 
    DLListNode *node = &header;
    DLListNode *nextNode = header.next;
    DLListNode *newNode = nullptr;

    while(node != &trailer){ // node iterates from header to the last element of the list to find node p

        if(node == &p){ // once node p is found, insert a new list node of obj between p and the node after
            newNode = new DLListNode(obj, node, nextNode);

            node->next = newNode;
            nextNode->prev = newNode;

            break; // new obj inserted into DLL, no need to continue loop
        }

        node = nextNode;
        nextNode = nextNode->next;
    }
}

void DLList::insert_before(DLListNode &p, int obj)  // a new node containing obj after node p of the list
{
    DLListNode *prevNode, *node = &header;
    DLListNode *newNode = nullptr;

    while(node != &trailer){ // node iterates from header to the last element of the list to find node p
        prevNode = node;
        node = node->next;

        if(node == &p){
            newNode = new DLListNode(obj, prevNode, node);

            node->prev = newNode;
            prevNode->next = newNode;

            break;
        }
    }
}

int DLList::remove_after(DLListNode &p)
{
    if(is_empty()) {throw "Empty DLList";} // empty DLL check

    int returnObj = 0;
    DLListNode *node = &header;
    DLListNode *removeNode, *newNext;

    while(node->next != &trailer){
        if(node == &p){
            removeNode = node->next;
            newNext = removeNode->next;

            returnObj = removeNode->obj;

            delete removeNode;

            node->next = newNext;
            newNext->prev = node;
            break;
        }
        node = node->next;
    }


    return returnObj;
}

int DLList::remove_before(DLListNode &p)
{
    if(is_empty()) {throw "Empty DLList";} // empty DLL check
    
    int returnObj = 0;
    DLListNode *node = header.next;
    DLListNode *removeNode, *newPrev;

    while(node != &trailer){
        if(node == &p){
            removeNode = node->prev;
            newPrev = removeNode->prev;

            returnObj = removeNode->obj;

            delete removeNode;

            node->prev = newPrev;
            newPrev->next = node;
            break;
        }
        node = node->next;
    }


    return returnObj;

}

ostream &operator<<(ostream &out, const DLList &dll)
{
    DLListNode *node = dll.first_node();

    while(node != dll.after_last_node()){
        out << node->obj;
        if(node->next != dll.after_last_node()){out << ", ";}
        node = node->next;
    }
    return out;
}
