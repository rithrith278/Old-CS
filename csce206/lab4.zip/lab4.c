#include <stdio.h>

int main()
{
    int startNum = 0;
    
    printf("Enter the starting number for the countdown: ");
    
    scanf("%d", &startNum);
    
    printf("Countdown:\n");
    
    for(int i=startNum;i>=0;--i){
        printf("%d\n", i);
    }
    
    printf("Launch!\n");

    return 0;
}
