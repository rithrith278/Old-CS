#include <stdio.h>
#include <stdlib.h>

int main() {
    /**
     * @brief 
     * Create a character array input to get the user string
     * Then fill the array *hint use fgets* with the user input
     */
    char input[500];
    fgets(input, 500, stdin);


    FILE *file = fopen("output-lab-6.txt", "w");
    

    /**
     * @brief 
     * Handle error checking if the file is null
     */
    if(file == NULL){
        return 1;
    }

    /**
     * @brief 
     * Write the input string to the text file
     */
    fprintf(file, "%s", input);


    /**
     * @brief 
     * Close the file after writing
     */
    fclose(file);

    // Open the file in read mode
    file = fopen("output-lab-6.txt", "r");
    /**
     * @brief 
     * Handle error checking if the file is null
     */
    if(file == NULL){
        return 1;
    }

    /**
     * @brief 
     * Read and display the content of the text file
     */
    fgets(input, 500, file);

    /**
     * @brief 
     * Close the file after reading
     */
    fclose(file);

    return 0;
}
