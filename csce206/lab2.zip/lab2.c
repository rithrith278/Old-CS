/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// declare functions
int simulateNavigation();

int main(){
    
    // randomly get numbers for current and next direction
    
    int currDirectionNum = simulateNavigation();
    int nextDirectionNum = simulateNavigation();
    
    
    /* 
      map numbers to directions
      number to direction map
      1 - North
      2 - East
      3 - South
      4 - West
    */
    
    char currDirectionStr[6];
    char nextDirectionStr[6];
    
    // get current cardinal direction
    if (currDirectionNum == 1){
        strcpy(currDirectionStr, "North");
    }
    else if (currDirectionNum == 2){
        strcpy(currDirectionStr, "East");
    }
    else if (currDirectionNum == 3){
        strcpy(currDirectionStr, "South");
    }
    else{
        strcpy(currDirectionStr, "West");
    }
    
    // get next cardinal direction
    if (nextDirectionNum == 1){
        strcpy(nextDirectionStr, "North");
    }
    else if (nextDirectionNum == 2){
        strcpy(nextDirectionStr, "East");
    }
    else if (nextDirectionNum == 3){
        strcpy(nextDirectionStr, "South");
    }
    else{
        strcpy(nextDirectionStr, "West");
    }
    
    
    /*
      output instructions based on next cardinal directions
      Different : Driving east, then turn north onto the next street.
      Same : Continue straight, heading east.
    */
    
    if(currDirectionNum == nextDirectionNum){
        // print instruction if current and next direction are the same
        printf("Continue straight, heading %s.\n", currDirectionStr);
    }
    else{
        printf("Driving %s, then turn %s onto the next street.\n", currDirectionStr, nextDirectionStr);
    }
    

    return 0;
}


int simulateNavigation(){
    /* 
      return random number from 1 to 4
      1 - North
      2 - East
      3 - South
      4 - West
    */
    return (rand() % 4) + 1;
}
