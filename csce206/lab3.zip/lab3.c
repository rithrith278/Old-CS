/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int firstNum;
    int secondNum;
    
    // Print prompt for first number
    printf("Enter the first number: ");
    
    // Input first number
    scanf("%d", &firstNum);
    
    // Print prompt for second number
    printf("Enter the second number: ");
    
    // Input second number
    scanf("%d", &secondNum);
    
    // if-else branch to compare numbers and print correct answer
    if (firstNum < secondNum){ // first less than second
        printf("%d is less than %d", firstNum, secondNum);
    }
    else if (firstNum == secondNum){ // first equal to second
        printf("%d is equal to %d", firstNum, secondNum);
    }
    else { // first greater than second
        printf("%d is greater than %d", firstNum, secondNum);
    }
    
    printf("\n");

    return 0;
}
