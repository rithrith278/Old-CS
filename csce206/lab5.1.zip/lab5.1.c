#include <stdlib.h>
#include <stdio.h>
#include "testArray.h"
void fillArray(double array[4])
{
    /**
     * @brief 
     * Fill in this function
     * TODO fill in array with user input
     */

    for(int i=0;i<3;++i){
        scanf("%lf", &array[i]);
        array[3] += array[i];
    }
    array[3] /= 3.0;
}

int main(){
    double array[4];
    fillArray(array);
    testArray(array);
    return 0;
}