// testArray.h
#ifndef TEST_ARRAY_H
#define TEST_ARRAY_H

#include <stdlib.h>
#include <stdio.h>
void testArray(double array[4]){
    for(int k=0; k<4; k++){
        if (k==0)
        {
            printf("[%lf,",array[k]);
        }else if(k==3){
            printf("%lf]",array[k]);
        }else{
            printf("%lf,",array[k]);
        }
    }
}

#endif // TEST_ARRAY_H