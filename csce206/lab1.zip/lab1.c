/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i = 4;
    float f = 4.2;
    double d = 8.0;
    char c = 'c';
    
    printf("Integer: %d size: %zu bytes\n", i, sizeof(i));
    
    printf("Float: %f size: %zu bytes\n", f, sizeof(f));
    
    printf("Double %f size: %zu bytes\n", d, sizeof(d));
    
    printf("Char: %c size: %zu bytes\n", c, sizeof(c));

    return 0;
}
