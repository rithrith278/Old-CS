// testArray.h
#ifndef TEST_ARRAY_H
#define TEST_ARRAY_H

#include <stdlib.h>
#include <stdio.h>

void testArray(double array[3][4]){
    for(int i=0; i<3; i++){
        for(int k=0; k<4; k++){
            if(k==0){
                if(i==0){
                    printf("[");
                }
                printf("[%lf,",array[i][k]);
            }
            else if(k==3){
                if(i!=2){
                    printf("%lf],",array[i][k]);
                }
                if(i==2){
                    printf("%lf]]\n",array[i][k]);
                }
            }else{
                printf("%lf,",array[i][k]);
            }
        }
    }
}

#endif // TEST_ARRAY_H
