#include <stdlib.h>
#include <stdio.h>
#include "testArray.h"
void fillArray(double array[3][4])
{
    /**
     * @brief 
     * Fill in function
     * TODO Fill in the given array with user input
     */
    for(int r=0;r<3;++r){
        for(int c=0;c<3;++c){
            scanf("%lf", &array[r][c]);
            array[r][3] += array[r][c];
        }
        array[r][3] /= 3;
    }
}

int main(){
    double array[3][4];
    fillArray(array);
    testArray(array);
}